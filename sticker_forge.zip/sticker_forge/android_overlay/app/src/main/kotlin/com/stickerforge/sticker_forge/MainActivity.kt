package com.stickerforge.sticker_forge

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "stickerforge/tg")
            .setMethodCallHandler { call, result ->
                if (call.method != "importPack") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                val paths = call.argument<List<String>>("paths") ?: emptyList()
                val emojis = call.argument<List<String>>("emojis") ?: emptyList()
                try {
                    val uris = ArrayList<Uri>()
                    for (p in paths) {
                        uris.add(FileProvider.getUriForFile(this, "$packageName.fileprovider", File(p)))
                    }
                    val intent = Intent("org.telegram.messenger.CREATE_STICKER_PACK")
                    intent.type = "image/*"
                    intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                    intent.putStringArrayListExtra("STICKER_EMOJIS", ArrayList(emojis))
                    intent.putExtra("IMPORTER", packageName)
                    val clip = ClipData.newRawUri("", uris[0])
                    for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
                    intent.clipData = clip
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(intent)
                    result.success(true)
                } catch (e: ActivityNotFoundException) {
                    result.error("NO_TG", "Telegram не найден или устарел (нужна версия 7.8+)", null)
                } catch (e: Exception) {
                    result.error("ERR", e.message, null)
                }
            }
    }
}
