import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;

class _Job {
  final String path;
  final List<double>? face; // left, top, width, height
  _Job(this.path, this.face);
}

/// Находит лицо (ML Kit, на устройстве), вырезает и превращает в мультяшный круглый аватар.
Future<ui.Image> makeAvatar(String path) async {
  List<double>? face;
  final det = FaceDetector(options: FaceDetectorOptions(performanceMode: FaceDetectorMode.accurate));
  try {
    final faces = await det.processImage(InputImage.fromFilePath(path));
    if (faces.isNotEmpty) {
      faces.sort((a, b) =>
          (b.boundingBox.width * b.boundingBox.height).compareTo(a.boundingBox.width * a.boundingBox.height));
      final r = faces.first.boundingBox;
      face = [r.left, r.top, r.width, r.height];
    }
  } catch (_) {
    // без лица: возьмём центр кадра
  } finally {
    await det.close();
  }
  final png = await compute(_cartoon, _Job(path, face));
  final codec = await ui.instantiateImageCodec(png);
  return (await codec.getNextFrame()).image;
}

Uint8List _cartoon(_Job j) {
  var im = img.decodeImage(File(j.path).readAsBytesSync())!;
  im = img.bakeOrientation(im);
  final iw = im.width.toDouble(), ih = im.height.toDouble();
  double cx, cy, side;
  if (j.face != null) {
    final f = j.face!;
    cx = f[0] + f[2] / 2;
    cy = f[1] + f[3] / 2 - f[3] * 0.08;
    side = max(f[2], f[3]) * 1.9;
  } else {
    cx = iw / 2;
    cy = ih / 2;
    side = min(iw, ih) * 0.9;
  }
  side = min(side, min(iw, ih));
  final x0 = (cx - side / 2).clamp(0.0, iw - side).toDouble();
  final y0 = (cy - side / 2).clamp(0.0, ih - side).toDouble();
  final sx = x0.round(), sy = y0.round();
  final sw = min(side.round(), min(im.width - sx, im.height - sy));
  const n = 320;
  var c = img.copyCrop(im, x: sx, y: sy, width: sw, height: sw);
  c = img.copyResize(c, width: n, height: n, interpolation: img.Interpolation.cubic);
  c = c.convert(numChannels: 4);
  var cur = Uint8List.fromList(c.getBytes(order: img.ChannelOrder.rgba));

  // 1) Сглаживание с сохранением границ (билатеральный фильтр, 2 прохода)
  final lut = List<double>.generate(766, (d) => exp(-(d * d) / (2 * 60.0 * 60.0)));
  final sp = List<double>.generate(49, (k) {
    final dx = k % 7 - 3, dy = k ~/ 7 - 3;
    return exp(-(dx * dx + dy * dy) / 8.0);
  });
  for (var pass = 0; pass < 2; pass++) {
    final out = Uint8List.fromList(cur);
    for (var y = 0; y < n; y++) {
      for (var x = 0; x < n; x++) {
        final i = (y * n + x) * 4;
        double sr = 0, sg = 0, sb = 0, sw2 = 0;
        for (var dy = -3; dy <= 3; dy++) {
          final yy = y + dy;
          if (yy < 0 || yy >= n) continue;
          for (var dx = -3; dx <= 3; dx++) {
            final xx = x + dx;
            if (xx < 0 || xx >= n) continue;
            final k = (yy * n + xx) * 4;
            final d = (cur[k] - cur[i]).abs() + (cur[k + 1] - cur[i + 1]).abs() + (cur[k + 2] - cur[i + 2]).abs();
            final w = sp[(dy + 3) * 7 + (dx + 3)] * lut[d];
            sr += cur[k] * w;
            sg += cur[k + 1] * w;
            sb += cur[k + 2] * w;
            sw2 += w;
          }
        }
        out[i] = (sr / sw2).round();
        out[i + 1] = (sg / sw2).round();
        out[i + 2] = (sb / sw2).round();
      }
    }
    cur = out;
  }

  // 2) Яркость для контуров (Собель)
  final lum = Float32List(n * n);
  for (var i = 0; i < n * n; i++) {
    lum[i] = 0.299 * cur[i * 4] + 0.587 * cur[i * 4 + 1] + 0.114 * cur[i * 4 + 2];
  }

  // 3) Насыщенность + постеризация + тёмные контуры + круглая маска
  final res = Uint8List(n * n * 4);
  for (var y = 0; y < n; y++) {
    for (var x = 0; x < n; x++) {
      final i = y * n + x;
      final o = i * 4;
      double r = cur[o].toDouble(), g = cur[o + 1].toDouble(), b = cur[o + 2].toDouble();
      final gray = 0.299 * r + 0.587 * g + 0.114 * b;
      r = gray + (r - gray) * 1.4;
      g = gray + (g - gray) * 1.4;
      b = gray + (b - gray) * 1.4;
      r = ((r.clamp(0, 255) / 40).floor() * 40 + 20).clamp(0, 255).toDouble();
      g = ((g.clamp(0, 255) / 40).floor() * 40 + 20).clamp(0, 255).toDouble();
      b = ((b.clamp(0, 255) / 40).floor() * 40 + 20).clamp(0, 255).toDouble();
      if (x > 0 && y > 0 && x < n - 1 && y < n - 1) {
        final gx = -lum[i - n - 1] - 2 * lum[i - 1] - lum[i + n - 1] + lum[i - n + 1] + 2 * lum[i + 1] + lum[i + n + 1];
        final gy = -lum[i - n - 1] - 2 * lum[i - n] - lum[i - n + 1] + lum[i + n - 1] + 2 * lum[i + n] + lum[i + n + 1];
        if (gx * gx + gy * gy > 140 * 140) {
          r = 35;
          g = 25;
          b = 40;
        }
      }
      final ddx = (x - n / 2 + 0.5) / (n / 2), ddy = (y - n / 2 + 0.5) / (n / 2);
      final d = sqrt(ddx * ddx + ddy * ddy);
      final a = (((1 - d) / 0.04).clamp(0.0, 1.0) * 255).round();
      res[o] = r.round();
      res[o + 1] = g.round();
      res[o + 2] = b.round();
      res[o + 3] = a;
    }
  }
  final out = img.Image.fromBytes(width: n, height: n, bytes: res.buffer, numChannels: 4);
  return Uint8List.fromList(img.encodePng(out));
}
