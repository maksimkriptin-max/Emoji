import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'cartoon.dart';
import 'exporter.dart';
import 'painter.dart';
import 'scenes.dart';

void main() => runApp(const StickerForgeApp());

class StickerForgeApp extends StatelessWidget {
  const StickerForgeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'StickerForge',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF7C4DFF), brightness: Brightness.dark, useMaterial3: true),
        home: const HomePage(),
      );
}

Future<T?> withProgress<T>(BuildContext context, String text, Future<T> Function() job) async {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        content: Row(children: [
          const CircularProgressIndicator(),
          const SizedBox(width: 20),
          Expanded(child: Text(text)),
        ]),
      ),
    ),
  );
  try {
    return await job();
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e')));
    }
    return null;
  } finally {
    if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Future<void> _pick(BuildContext context, ImageSource src) async {
    final f = await ImagePicker().pickImage(source: src, maxWidth: 2000, imageQuality: 92);
    if (f == null || !context.mounted) return;
    final avatar = await withProgress(context, 'Рисую мультяшный портрет…', () => makeAvatar(f.path));
    if (avatar == null || !context.mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => ThemePage(avatar: avatar)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('🎭', style: TextStyle(fontSize: 84)),
              const SizedBox(height: 12),
              Text('StickerForge', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 8),
              const Text('Сделай фото, выбери тему, получи анимированные стикеры', textAlign: TextAlign.center),
              const SizedBox(height: 36),
              FilledButton.icon(
                onPressed: () => _pick(context, ImageSource.camera),
                icon: const Icon(Icons.photo_camera),
                label: const Padding(padding: EdgeInsets.all(14), child: Text('Сделать фото')),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => _pick(context, ImageSource.gallery),
                icon: const Icon(Icons.photo_library),
                label: const Padding(padding: EdgeInsets.all(12), child: Text('Выбрать из галереи')),
              ),
            ]),
          ),
        ),
      );
}

class ThemePage extends StatelessWidget {
  final ui.Image avatar;
  const ThemePage({super.key, required this.avatar});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Выбери тему')),
        body: Column(children: [
          SizedBox(height: 120, child: RawImage(image: avatar, fit: BoxFit.contain)),
          Expanded(
            child: GridView.count(
              crossAxisCount: 3,
              padding: const EdgeInsets.all(12),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              children: [
                for (final th in themes)
                  InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => StickersPage(theme: th, avatar: avatar))),
                    child: Ink(
                      decoration: BoxDecoration(
                        color: th.scenes.first.color.withAlpha(70),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: th.scenes.first.color, width: 2),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text(th.emoji, style: const TextStyle(fontSize: 40)),
                        const SizedBox(height: 6),
                        Text(th.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ]),
                    ),
                  ),
              ],
            ),
          ),
        ]),
      );
}

class StickersPage extends StatefulWidget {
  final StickerTheme theme;
  final ui.Image avatar;
  const StickersPage({super.key, required this.theme, required this.avatar});
  @override
  State<StickersPage> createState() => _StickersPageState();
}

class _StickersPageState extends State<StickersPage> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl =
      AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  static const _tg = MethodChannel('stickerforge/tg');

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _share(int i, bool gif) async {
    final s = widget.theme.scenes[i];
    final path = await withProgress(
        context, gif ? 'Собираю GIF…' : 'Собираю WEBM…', () => exportSticker(s, widget.avatar, '${widget.theme.id}_$i', gif: gif));
    if (path != null) await Share.shareXFiles([XFile(path)]);
  }

  Future<void> _toTelegram() async {
    final scenes = widget.theme.scenes;
    final ok = await withProgress<bool>(context, 'Готовлю стикеры для Telegram…', () async {
      final paths = <String>[];
      for (var i = 0; i < scenes.length; i++) {
        paths.add(await exportSticker(scenes[i], widget.avatar, '${widget.theme.id}_$i'));
      }
      await _tg.invokeMethod('importPack', {'paths': paths, 'emojis': [for (final s in scenes) s.emoji]});
      return true;
    });
    if (ok == null && mounted) {
      // ошибка уже показана; подсказка про Telegram
    }
  }

  void _menu(int i) => showModalBottomSheet(
        context: context,
        builder: (_) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              leading: const Icon(Icons.movie),
              title: const Text('Поделиться как WEBM (Telegram)'),
              onTap: () {
                Navigator.pop(context);
                _share(i, false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.gif_box),
              title: const Text('Поделиться как GIF'),
              onTap: () {
                Navigator.pop(context);
                _share(i, true);
              },
            ),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final th = widget.theme;
    return Scaffold(
      appBar: AppBar(title: Text('${th.emoji} ${th.name}')),
      body: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => GridView.builder(
          padding: const EdgeInsets.all(12),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12),
          itemCount: th.scenes.length,
          itemBuilder: (_, i) => GestureDetector(
            onTap: () => _menu(i),
            child: Container(
              decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(16)),
              child: CustomPaint(painter: StickerPainter(th.scenes[i], widget.avatar, _ctrl.value)),
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(
            onPressed: _toTelegram,
            icon: const Icon(Icons.send),
            label: const Padding(padding: EdgeInsets.all(12), child: Text('Добавить пак в Telegram')),
          ),
        ),
      ),
    );
  }
}
