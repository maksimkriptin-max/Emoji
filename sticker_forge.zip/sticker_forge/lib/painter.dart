import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'scenes.dart';

/// Рисует один кадр стикера в системе координат 512x512.
/// t in [0,1): все движения периодичны, поэтому анимация зациклена без шва.
class StickerPainter extends CustomPainter {
  final Scene s;
  final ui.Image face;
  final double t;
  StickerPainter(this.s, this.face, this.t);

  static const tau = 2 * pi;

  @override
  void paint(Canvas c, Size size) {
    c.save();
    c.scale(size.width / 512);
    c.drawCircle(const Offset(256, 255), 232, Paint()..color = s.color.withAlpha(60));

    double dx = 0, dy = 0, rot = 0, sc = 1;
    final w = sin(tau * t);
    switch (s.anim) {
      case 'bounce':
        dy = -20 * sin(pi * ((t * 2) % 1));
        break;
      case 'wobble':
        rot = 0.12 * w;
        break;
      case 'pulse':
        sc = 1 + 0.05 * w;
        break;
      case 'shake':
        dx = 9 * sin(tau * 3 * t);
        break;
      case 'nod':
        rot = 0.06 * w;
        dy = 8 * sin(tau * 2 * t);
        break;
    }

    c.save();
    c.translate(256 + dx, 330 + dy);
    c.rotate(rot);
    c.scale(sc * 0.92);
    c.translate(-256, -330);
    _body(c);
    _head(c);
    _acc(c);
    c.restore();

    for (var i = 0; i < s.props.length; i++) {
      _prop(c, s.props[i], i);
    }
    _caption(c);
    c.restore();
  }

  void _body(Canvas c) {
    final r = RRect.fromRectAndRadius(const Rect.fromLTWH(131, 300, 250, 150), const Radius.circular(70));
    c.drawRRect(r.inflate(7), Paint()..color = Colors.white);
    c.drawRRect(r, Paint()..color = s.shirt);
    c.drawRRect(
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..color = Colors.black26);
  }

  void _head(Canvas c) {
    const ctr = Offset(256, 185);
    c.drawCircle(ctr, 133, Paint()..color = Colors.white);
    final src = Rect.fromLTWH(0, 0, face.width.toDouble(), face.height.toDouble());
    c.drawImageRect(face, src, Rect.fromCircle(center: ctr, radius: 125), Paint()..filterQuality = FilterQuality.medium);
  }

  void _acc(Canvas c) {
    switch (s.acc) {
      case Acc.none:
        break;
      case Acc.santa:
        final hat = Path()
          ..moveTo(140, 112)
          ..cubicTo(150, 20, 250, -5, 345, 45)
          ..lineTo(372, 112)
          ..close();
        c.drawPath(hat, Paint()..color = const Color(0xFFD32F2F));
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(130, 98, 252, 34), const Radius.circular(17)),
            Paint()..color = Colors.white);
        c.drawCircle(const Offset(348, 42), 24, Paint()..color = Colors.white);
        break;
      case Acc.chef:
        final p = Paint()..color = Colors.white;
        final o = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = Colors.black26;
        for (final e in const [Offset(205, 70), Offset(307, 70)]) {
          c.drawCircle(e, 42, p);
          c.drawCircle(e, 42, o);
        }
        c.drawCircle(const Offset(256, 48), 50, p);
        c.drawCircle(const Offset(256, 48), 50, o);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(165, 92, 182, 38), const Radius.circular(10)), p);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(165, 92, 182, 38), const Radius.circular(10)), o);
        break;
      case Acc.party:
        final cone = Path()
          ..moveTo(190, 108)
          ..lineTo(322, 108)
          ..lineTo(256, -8)
          ..close();
        c.drawPath(cone, Paint()..color = const Color(0xFFFF4081));
        c.drawCircle(const Offset(240, 70), 7, Paint()..color = Colors.yellow);
        c.drawCircle(const Offset(272, 50), 7, Paint()..color = Colors.cyanAccent);
        c.drawCircle(const Offset(256, 92), 7, Paint()..color = Colors.white);
        c.drawCircle(const Offset(256, -6), 16, Paint()..color = Colors.yellow);
        break;
      case Acc.shades:
        final k = Paint()..color = const Color(0xFF111111);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(160, 160, 95, 50), const Radius.circular(20)), k);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(257, 160, 95, 50), const Radius.circular(20)), k);
        c.drawRect(const Rect.fromLTWH(250, 172, 12, 8), k);
        final sh = Paint()
          ..color = Colors.white54
          ..strokeWidth = 4
          ..strokeCap = StrokeCap.round;
        c.drawLine(const Offset(175, 172), const Offset(195, 168), sh);
        c.drawLine(const Offset(272, 172), const Offset(292, 168), sh);
        break;
      case Acc.headset:
        c.drawArc(
            Rect.fromCircle(center: const Offset(256, 185), radius: 138),
            pi,
            pi,
            false,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 14
              ..color = const Color(0xFF263238));
        final cup = Paint()..color = const Color(0xFF37474F);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(104, 160, 36, 72), const Radius.circular(14)), cup);
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(372, 160, 36, 72), const Radius.circular(14)), cup);
        final mic = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 6
          ..color = const Color(0xFF263238);
        c.drawPath(
            Path()
              ..moveTo(120, 230)
              ..quadraticBezierTo(130, 280, 200, 266),
            mic);
        c.drawCircle(const Offset(204, 265), 9, Paint()..color = const Color(0xFF263238));
        break;
      case Acc.band:
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(131, 104, 250, 24), const Radius.circular(12)),
            Paint()..color = const Color(0xFFE53935));
        c.drawRect(const Rect.fromLTWH(131, 113, 250, 5), Paint()..color = Colors.white);
        break;
    }
  }

  void _prop(Canvas c, Prop p, int i) {
    final ph = i * 0.17;
    final a = tau * (t + ph);
    double x = p.x, y = p.y, rot = 0, sc = 1;
    switch (p.m) {
      case 'bob':
        y += 10 * sin(a);
        break;
      case 'spin':
        rot = tau * t;
        break;
      case 'pulse':
        sc = 1 + 0.18 * sin(a);
        break;
      case 'shake':
        x += 8 * sin(tau * 3 * t + ph * tau);
        break;
      case 'orbit':
        x += 14 * cos(tau * t);
        y += 14 * sin(tau * t);
        break;
      case 'fall':
        y = ((p.y + 560 * t) % 560) - 20;
        break;
    }
    final tp = TextPainter(
      text: TextSpan(text: p.e, style: TextStyle(fontSize: p.size)),
      textDirection: TextDirection.ltr,
    )..layout();
    c.save();
    c.translate(x, y);
    c.rotate(rot);
    c.scale(sc);
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    c.restore();
  }

  TextPainter _mk(double f, Paint paint) => TextPainter(
        text: TextSpan(
            text: s.cap,
            style: TextStyle(fontSize: f, fontWeight: FontWeight.w900, foreground: paint)),
        textDirection: TextDirection.ltr,
      )..layout();

  void _caption(Canvas c) {
    double fs = 50;
    final white = Paint()..color = Colors.white;
    var fill = _mk(fs, white);
    while (fill.width > 480 && fs > 20) {
      fs -= 2;
      fill = _mk(fs, white);
    }
    final stroke = _mk(
        fs,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 9
          ..strokeJoin = StrokeJoin.round
          ..color = const Color(0xFF222222));
    final o = Offset(256 - fill.width / 2, 478 - fill.height / 2);
    stroke.paint(c, o);
    fill.paint(c, o);
  }

  @override
  bool shouldRepaint(covariant StickerPainter old) => old.t != t || old.s != s || old.face != face;
}
