import 'dart:io';
import 'dart:ui' as ui;
import 'package:ffmpeg_kit_flutter_new_full/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_full/return_code.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'painter.dart';
import 'scenes.dart';

const int fps = 15;
const int frameCount = 30; // 2 секунды, цикл

/// Рендерит кадры сцены и кодирует в WEBM (VP9 + альфа, <=256 КБ) или GIF.
Future<String> exportSticker(Scene s, ui.Image face, String key, {bool gif = false}) async {
  final base = await getApplicationSupportDirectory();
  final work = Directory('${base.path}/work/$key');
  if (work.existsSync()) work.deleteSync(recursive: true);
  work.createSync(recursive: true);
  final outDir = Directory('${base.path}/out')..createSync(recursive: true);

  for (var i = 0; i < frameCount; i++) {
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    StickerPainter(s, face, i / frameCount).paint(canvas, const Size(512, 512));
    final pic = rec.endRecording();
    final im = await pic.toImage(512, 512);
    final bd = await im.toByteData(format: ui.ImageByteFormat.png);
    File('${work.path}/f_${i.toString().padLeft(3, '0')}.png').writeAsBytesSync(bd!.buffer.asUint8List());
    im.dispose();
    pic.dispose();
  }

  final input = '${work.path}/f_%03d.png';
  String result;
  if (gif) {
    result = '${outDir.path}/$key.gif';
    final cmd = '-y -framerate $fps -i $input '
        '-vf "split[a][b];[a]palettegen=reserve_transparent=1[p];[b][p]paletteuse=alpha_threshold=128" '
        '-loop 0 $result';
    final session = await FFmpegKit.execute(cmd);
    if (!ReturnCode.isSuccess(await session.getReturnCode())) {
      throw Exception('Не удалось собрать GIF');
    }
  } else {
    result = '${outDir.path}/$key.webm';
    var ok = false;
    for (final crf in [34, 38, 42, 46, 50, 54, 58]) {
      final cmd = '-y -framerate $fps -i $input -c:v libvpx-vp9 -pix_fmt yuva420p '
          '-b:v 0 -crf $crf -auto-alt-ref 0 -deadline good -cpu-used 4 -an $result';
      final session = await FFmpegKit.execute(cmd);
      if (!ReturnCode.isSuccess(await session.getReturnCode())) continue;
      if (File(result).lengthSync() <= 256 * 1024) {
        ok = true;
        break;
      }
    }
    if (!ok) throw Exception('Не удалось уложиться в 256 КБ для Telegram');
  }
  work.deleteSync(recursive: true);
  return result;
}
