import 'dart:ui';

enum Acc { none, santa, chef, party, shades, headset, band }

class Prop {
  final String e;
  final double x, y, size;
  final String m; // bob spin pulse shake orbit fall
  const Prop(this.e, this.x, this.y, this.size, this.m);
}

class Scene {
  final String cap;
  final Acc acc;
  final String anim; // bounce wobble pulse shake nod
  final Color color, shirt;
  final List<Prop> props;
  const Scene(this.cap, this.acc, this.anim, this.color, this.shirt, this.props);
  String get emoji => props.first.e;
}

class StickerTheme {
  final String id, name, emoji;
  final List<Scene> scenes;
  const StickerTheme(this.id, this.name, this.emoji, this.scenes);
}

class _R {
  final String cap;
  final Acc acc;
  final String anim;
  final List<Prop> props;
  const _R(this.cap, this.acc, this.anim, this.props);
}

StickerTheme _t(String id, String name, String emoji, int color, int shirt, List<_R> rows) =>
    StickerTheme(id, name, emoji, [
      for (final r in rows) Scene(r.cap, r.acc, r.anim, Color(color), Color(shirt), r.props)
    ]);

final List<StickerTheme> themes = [
  _t('it', 'Айтишник', '💻', 0xFFE91E63, 0xFFD81B8C, const [
    _R('FIX', Acc.headset, 'wobble', [Prop('💻', 256, 390, 95, 'bob'), Prop('🐛', 62, 110, 64, 'shake'), Prop('☕', 450, 120, 60, 'bob')]),
    _R('БАГ!', Acc.none, 'shake', [Prop('🐛', 70, 100, 70, 'shake'), Prop('🔥', 445, 330, 70, 'pulse'), Prop('💻', 256, 390, 90, 'shake')]),
    _R('COMMIT', Acc.headset, 'bounce', [Prop('✅', 70, 110, 70, 'pulse'), Prop('💻', 256, 390, 90, 'bob'), Prop('🚀', 445, 110, 66, 'bob')]),
    _R('Деплой в пятницу', Acc.shades, 'nod', [Prop('🚀', 445, 300, 70, 'bob'), Prop('😱', 65, 300, 66, 'shake'), Prop('💻', 256, 390, 90, 'bob')]),
    _R('Кофе → код', Acc.none, 'bounce', [Prop('☕', 256, 390, 90, 'pulse'), Prop('⌨️', 65, 330, 66, 'bob'), Prop('💡', 445, 110, 62, 'pulse')]),
    _R('Хакер', Acc.shades, 'wobble', [Prop('👾', 65, 110, 66, 'bob'), Prop('🔒', 445, 110, 62, 'pulse'), Prop('💻', 256, 390, 92, 'shake')]),
  ]),
  _t('chef', 'Повар', '🍳', 0xFFFF9800, 0xFFF5F5F5, const [
    _R('Шеф!', Acc.chef, 'bounce', [Prop('🍳', 256, 390, 95, 'bob'), Prop('🔥', 62, 330, 64, 'pulse'), Prop('🧂', 445, 120, 60, 'orbit')]),
    _R('Вкусно!', Acc.chef, 'wobble', [Prop('🍕', 256, 390, 95, 'bob'), Prop('❤️', 445, 110, 60, 'pulse'), Prop('⭐', 62, 110, 60, 'spin')]),
    _R('Горячо!', Acc.chef, 'shake', [Prop('🔥', 62, 330, 70, 'pulse'), Prop('🍲', 256, 390, 95, 'shake'), Prop('♨️', 445, 120, 58, 'bob')]),
    _R('Нарезаю', Acc.chef, 'nod', [Prop('🔪', 256, 390, 85, 'shake'), Prop('🥕', 62, 320, 66, 'bob'), Prop('🧅', 445, 320, 64, 'bob')]),
    _R('Соль!', Acc.chef, 'pulse', [Prop('🧂', 256, 390, 90, 'shake'), Prop('✨', 65, 110, 60, 'spin'), Prop('✨', 445, 110, 60, 'spin')]),
    _R('Приятного!', Acc.chef, 'bounce', [Prop('🍰', 256, 390, 92, 'bob'), Prop('🍷', 65, 330, 64, 'bob'), Prop('🥐', 445, 330, 64, 'bob')]),
  ]),
  _t('brutal', 'Брутал', '💪', 0xFF607D8B, 0xFF222222, const [
    _R('БРУТАЛ', Acc.shades, 'pulse', [Prop('💪', 65, 330, 74, 'pulse'), Prop('🔥', 445, 330, 74, 'pulse'), Prop('🖤', 256, 390, 70, 'pulse')]),
    _R('Я ТУТ ГЛАВНЫЙ', Acc.shades, 'shake', [Prop('👑', 445, 110, 66, 'bob'), Prop('💥', 65, 110, 66, 'pulse'), Prop('👊', 256, 390, 80, 'shake')]),
    _R('Респект', Acc.shades, 'bounce', [Prop('🤝', 256, 390, 80, 'bob'), Prop('💯', 65, 110, 64, 'pulse'), Prop('🔥', 445, 110, 64, 'pulse')]),
    _R('Босс', Acc.shades, 'wobble', [Prop('💼', 256, 390, 85, 'bob'), Prop('💰', 65, 330, 66, 'spin'), Prop('💎', 445, 330, 64, 'pulse')]),
    _R('Без паники', Acc.shades, 'nod', [Prop('🥶', 65, 110, 64, 'bob'), Prop('🧊', 445, 110, 60, 'bob'), Prop('👊', 256, 390, 80, 'shake')]),
    _R('Сила!', Acc.none, 'pulse', [Prop('🏋️', 256, 390, 95, 'bob'), Prop('💥', 65, 320, 66, 'pulse'), Prop('💪', 445, 320, 70, 'pulse')]),
  ]),
  _t('flirt', 'Кокетство', '😘', 0xFFFF4081, 0xFFFF6FA8, const [
    _R('Приветик', Acc.none, 'wobble', [Prop('💋', 65, 330, 66, 'pulse'), Prop('💕', 445, 110, 64, 'bob'), Prop('🌹', 256, 390, 80, 'bob')]),
    _R('Чмок!', Acc.none, 'bounce', [Prop('💋', 256, 390, 85, 'pulse'), Prop('❤️', 65, 110, 64, 'pulse'), Prop('💖', 445, 110, 64, 'pulse')]),
    _R('Ну пожалуйста', Acc.none, 'pulse', [Prop('🙏', 256, 390, 80, 'bob'), Prop('✨', 65, 110, 60, 'spin'), Prop('💗', 445, 330, 62, 'pulse')]),
    _R('Подмигиваю', Acc.none, 'nod', [Prop('✨', 65, 110, 62, 'spin'), Prop('😉', 445, 330, 66, 'pulse'), Prop('💘', 256, 390, 80, 'bob')]),
    _R('Скучаю', Acc.none, 'wobble', [Prop('💌', 256, 390, 85, 'bob'), Prop('💭', 65, 110, 64, 'bob'), Prop('💞', 445, 110, 62, 'pulse')]),
    _R('Ты прелесть', Acc.none, 'bounce', [Prop('🌸', 65, 330, 66, 'spin'), Prop('🦋', 445, 330, 66, 'bob'), Prop('💝', 256, 390, 82, 'pulse')]),
  ]),
  _t('emo', 'Эмоции', '😱', 0xFFFFC107, 0xFFFFA000, const [
    _R('УРА!', Acc.none, 'bounce', [Prop('🎉', 65, 110, 70, 'spin'), Prop('🎊', 445, 110, 70, 'spin'), Prop('⭐', 256, 390, 80, 'pulse')]),
    _R('ШОК', Acc.none, 'shake', [Prop('😱', 256, 390, 85, 'shake'), Prop('❗', 65, 330, 66, 'pulse'), Prop('❗', 445, 330, 66, 'pulse')]),
    _R('Грущу', Acc.none, 'wobble', [Prop('😢', 256, 390, 85, 'bob'), Prop('🌧️', 65, 110, 66, 'bob'), Prop('💧', 445, 100, 60, 'fall')]),
    _R('Злюсь', Acc.none, 'shake', [Prop('💢', 65, 110, 70, 'pulse'), Prop('🔥', 445, 110, 66, 'pulse'), Prop('😡', 256, 390, 84, 'shake')]),
    _R('Смеюсь', Acc.none, 'bounce', [Prop('😂', 256, 390, 84, 'pulse'), Prop('🤣', 65, 330, 64, 'bob'), Prop('😄', 445, 330, 64, 'bob')]),
    _R('Думаю...', Acc.none, 'nod', [Prop('🤔', 256, 390, 84, 'bob'), Prop('💭', 65, 110, 66, 'bob'), Prop('❓', 445, 110, 64, 'pulse')]),
  ]),
  _t('office', 'Офис', '💼', 0xFF2196F3, 0xFF1E88E5, const [
    _R('Дедлайн!', Acc.none, 'shake', [Prop('⏰', 256, 390, 88, 'shake'), Prop('📄', 65, 330, 64, 'bob'), Prop('😰', 445, 110, 64, 'pulse')]),
    _R('Созвон', Acc.headset, 'nod', [Prop('📞', 65, 330, 64, 'bob'), Prop('💻', 256, 390, 88, 'bob'), Prop('🗓️', 445, 110, 60, 'pulse')]),
    _R('Отчёт готов', Acc.none, 'bounce', [Prop('📊', 256, 390, 90, 'bob'), Prop('✅', 65, 110, 66, 'pulse'), Prop('📈', 445, 110, 64, 'bob')]),
    _R('Кофе-брейк', Acc.none, 'wobble', [Prop('☕', 256, 390, 90, 'pulse'), Prop('🍩', 65, 330, 62, 'bob'), Prop('💤', 445, 110, 62, 'bob')]),
    _R('Совещание', Acc.none, 'nod', [Prop('📋', 256, 390, 84, 'bob'), Prop('🥱', 65, 110, 62, 'bob'), Prop('⏳', 445, 110, 64, 'spin')]),
    _R('Зарплата!', Acc.none, 'bounce', [Prop('💰', 256, 390, 90, 'pulse'), Prop('💵', 65, 100, 66, 'fall'), Prop('🤑', 445, 110, 66, 'bob')]),
  ]),
  _t('sport', 'Спорт', '⚽', 0xFFF44336, 0xFFE53935, const [
    _R('Гол!', Acc.band, 'bounce', [Prop('⚽', 256, 390, 90, 'bob'), Prop('🥅', 65, 330, 66, 'bob'), Prop('🏆', 445, 110, 66, 'pulse')]),
    _R('Качаю', Acc.band, 'pulse', [Prop('🏋️', 256, 390, 95, 'bob'), Prop('💪', 65, 330, 70, 'pulse'), Prop('🔥', 445, 110, 64, 'pulse')]),
    _R('Бегу', Acc.band, 'bounce', [Prop('👟', 256, 390, 85, 'shake'), Prop('💨', 65, 330, 66, 'shake'), Prop('⏱️', 445, 110, 62, 'pulse')]),
    _R('Чемпион', Acc.band, 'wobble', [Prop('🏆', 256, 390, 92, 'pulse'), Prop('🥇', 65, 110, 68, 'spin'), Prop('🎖️', 445, 110, 64, 'bob')]),
    _R('Бассейн', Acc.none, 'nod', [Prop('🏊', 256, 390, 88, 'bob'), Prop('🌊', 65, 330, 66, 'bob'), Prop('💦', 445, 100, 64, 'fall')]),
    _R('Баскетбол', Acc.band, 'bounce', [Prop('🏀', 256, 390, 90, 'bob'), Prop('🔥', 65, 110, 64, 'pulse'), Prop('⭐', 445, 110, 62, 'spin')]),
  ]),
  _t('gamer', 'Геймер', '🎮', 0xFF7C4DFF, 0xFF6A1B9A, const [
    _R('GG WP', Acc.headset, 'bounce', [Prop('🎮', 256, 390, 92, 'bob'), Prop('🏆', 65, 110, 64, 'pulse'), Prop('⚡', 445, 110, 64, 'pulse')]),
    _R('Лаги!', Acc.headset, 'shake', [Prop('📶', 65, 330, 64, 'shake'), Prop('😤', 445, 110, 64, 'pulse'), Prop('🖥️', 256, 390, 90, 'shake')]),
    _R('Босс убит', Acc.headset, 'wobble', [Prop('👾', 65, 110, 68, 'bob'), Prop('⚔️', 445, 110, 66, 'spin'), Prop('🎮', 256, 390, 88, 'bob')]),
    _R('Ещё раунд', Acc.headset, 'nod', [Prop('🕹️', 256, 390, 90, 'bob'), Prop('🔁', 65, 330, 64, 'spin'), Prop('🌙', 445, 110, 62, 'bob')]),
    _R('Лут!', Acc.headset, 'pulse', [Prop('💎', 256, 390, 86, 'pulse'), Prop('💰', 65, 110, 64, 'bob'), Prop('🎁', 445, 110, 64, 'bob')]),
    _R('AFK', Acc.headset, 'bounce', [Prop('🍕', 256, 390, 88, 'bob'), Prop('💤', 65, 110, 64, 'bob'), Prop('🥤', 445, 330, 64, 'bob')]),
  ]),
  _t('party', 'Вечеринка', '🎉', 0xFF00BCD4, 0xFF00ACC1, const [
    _R('Погнали!', Acc.party, 'bounce', [Prop('🎉', 65, 110, 70, 'spin'), Prop('🎊', 445, 110, 70, 'spin'), Prop('🥳', 256, 390, 80, 'pulse')]),
    _R('Тост!', Acc.party, 'wobble', [Prop('🥂', 256, 390, 92, 'bob'), Prop('✨', 65, 110, 62, 'spin'), Prop('🍾', 445, 330, 66, 'bob')]),
    _R('Танцуем', Acc.party, 'bounce', [Prop('🎵', 65, 330, 66, 'bob'), Prop('🎶', 445, 110, 66, 'bob'), Prop('💃', 256, 390, 86, 'shake')]),
    _R('Торт!', Acc.party, 'pulse', [Prop('🎂', 256, 390, 92, 'pulse'), Prop('🎈', 65, 110, 70, 'bob'), Prop('🎈', 445, 110, 70, 'bob')]),
    _R('DJ', Acc.headset, 'shake', [Prop('🎚️', 256, 390, 86, 'shake'), Prop('🔊', 65, 330, 64, 'pulse'), Prop('🎤', 445, 330, 64, 'bob')]),
    _R('Ещё по одной', Acc.party, 'nod', [Prop('🍹', 256, 390, 88, 'bob'), Prop('🎊', 65, 110, 64, 'spin'), Prop('🍸', 445, 330, 64, 'bob')]),
  ]),
  _t('love', 'Романтика', '💘', 0xFFE91E63, 0xFFC2185B, const [
    _R('Люблю', Acc.none, 'pulse', [Prop('❤️', 256, 390, 90, 'pulse'), Prop('💕', 65, 110, 66, 'bob'), Prop('💕', 445, 110, 66, 'bob')]),
    _R('Для тебя', Acc.none, 'bounce', [Prop('🌹', 256, 390, 92, 'bob'), Prop('💌', 65, 330, 64, 'bob'), Prop('✨', 445, 110, 62, 'spin')]),
    _R('Свидание', Acc.none, 'wobble', [Prop('🍷', 256, 390, 86, 'bob'), Prop('🕯️', 65, 330, 62, 'pulse'), Prop('🌙', 445, 110, 64, 'bob')]),
    _R('Навсегда', Acc.none, 'pulse', [Prop('💍', 256, 390, 86, 'pulse'), Prop('💞', 65, 110, 66, 'bob'), Prop('✨', 445, 110, 62, 'spin')]),
    _R('Обнимаю', Acc.none, 'wobble', [Prop('🤗', 256, 390, 84, 'bob'), Prop('💗', 65, 330, 64, 'pulse'), Prop('💗', 445, 330, 64, 'pulse')]),
    _R('Спокойной ночи', Acc.none, 'nod', [Prop('🌙', 65, 110, 70, 'bob'), Prop('⭐', 445, 110, 62, 'pulse'), Prop('💤', 256, 390, 80, 'bob')]),
  ]),
  _t('fish', 'Рыбалка', '🎣', 0xFF4CAF50, 0xFF558B2F, const [
    _R('Клюёт!', Acc.none, 'shake', [Prop('🎣', 256, 390, 92, 'shake'), Prop('🐟', 65, 330, 68, 'bob'), Prop('💦', 445, 330, 64, 'pulse')]),
    _R('Улов дня', Acc.none, 'bounce', [Prop('🐟', 256, 390, 90, 'bob'), Prop('🐠', 65, 110, 64, 'bob'), Prop('🐡', 445, 110, 64, 'bob')]),
    _R('Тишина...', Acc.none, 'nod', [Prop('🌅', 445, 110, 70, 'bob'), Prop('🎣', 256, 390, 88, 'bob'), Prop('🦆', 65, 330, 64, 'bob')]),
    _R('Червячок', Acc.none, 'wobble', [Prop('🐛', 256, 390, 80, 'bob'), Prop('🎣', 65, 330, 66, 'bob'), Prop('🐟', 445, 330, 64, 'bob')]),
    _R('Уха!', Acc.chef, 'pulse', [Prop('🍲', 256, 390, 90, 'bob'), Prop('🐟', 65, 110, 64, 'bob'), Prop('🔥', 445, 330, 64, 'pulse')]),
    _R('Щука!', Acc.none, 'bounce', [Prop('🦈', 256, 390, 86, 'shake'), Prop('🌊', 65, 330, 66, 'bob'), Prop('🎣', 445, 110, 66, 'bob')]),
  ]),
  _t('ny', 'Новый год', '🎄', 0xFF2E7D32, 0xFFD32F2F, const [
    _R('С Новым годом!', Acc.santa, 'bounce', [Prop('🎄', 256, 390, 92, 'bob'), Prop('🎁', 65, 330, 66, 'bob'), Prop('✨', 445, 110, 62, 'spin')]),
    _R('Ура!', Acc.santa, 'bounce', [Prop('🎆', 65, 110, 70, 'pulse'), Prop('🎇', 445, 110, 70, 'pulse'), Prop('🥂', 256, 390, 86, 'bob')]),
    _R('Снежок', Acc.santa, 'wobble', [Prop('❄️', 65, 100, 66, 'fall'), Prop('⛄', 256, 390, 88, 'bob'), Prop('❄️', 445, 200, 66, 'fall')]),
    _R('Подарок', Acc.santa, 'pulse', [Prop('🎁', 256, 390, 92, 'pulse'), Prop('🎀', 65, 330, 62, 'bob'), Prop('⭐', 445, 110, 62, 'spin')]),
    _R('Мандарины', Acc.santa, 'nod', [Prop('🍊', 256, 390, 86, 'bob'), Prop('🎄', 65, 330, 66, 'bob'), Prop('🍾', 445, 330, 66, 'bob')]),
    _R('Бой курантов', Acc.santa, 'shake', [Prop('🕛', 256, 390, 88, 'pulse'), Prop('🔔', 65, 110, 66, 'shake'), Prop('🎉', 445, 110, 66, 'spin')]),
  ]),
];
